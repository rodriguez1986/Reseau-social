document.getElementById('gameCanvas').width = 800;
document.getElementById('gameCanvas').height = 600;
console.log('Le jeu est prêt !');